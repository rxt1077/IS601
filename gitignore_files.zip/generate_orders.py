import random
from datetime import datetime
import pprint
import json
import argparse

pp = pprint.PrettyPrinter(indent=4, sort_dicts=False)

START_DATE = datetime(2023, 1, 1, 0, 0)
END_DATE = datetime(2024, 1, 1, 0, 0)

MIN_ITEMS = 1
MAX_ITEMS = 5

# There are repeats in these lists so that certain items/people are picked
# more often. This removes ties for most popular when generating a lot of
# orders
MENU = [
    ('Masala Dosa', 10.95),
    ('Masala Dosa', 10.95),
    ('Masala Dosa', 10.95),
    ('Masala Dosa', 10.95),
    ('Butter Masala Dosa', 12.95),
    ('Butter Masala Dosa', 12.95),
    ('Butter Masala Dosa', 12.95),
    ('Gun Powder Dosa', 13.95),
    ('Gun Powder Dosa', 13.95),
    ('Sada Dosa', 9.95),
    ('Paper Masala Dosa', 11.95),
    ('Ghee Roast Masala Dosa', 11.95),
    ('Mysore Masala Dosa', 11.95),
    ('Butter Mysore Masala Dosa', 11.95),
    ('Onion Chilli Masala Dosa', 11.95),
    ('Cheese Masala Dosa', 11.95),
    ('Cheese & Onion Chilli Masala Dosa', 12.95),
    ('Onion Rava Sada Dosa', 12.95),
    ('Onion Rava Masala Dosa', 13.95),
    ('Onion Chilli Rava Masala Dosa', 14.95),
    ('Onion Rava Mysore Masala Dosa', 14.95),
    ('Malgudi Onion Rava Masala Dosa', 14.95),
    ('Cheese Mysore Masala Dosa', 13.95),
    ('Madurai Masala Dosa', 12.95),
    ('Cheese Madurai Masala Dosa', 13.95),
]

PEOPLE = [
    ('Tom', '609-555-2301'),
    ('Tom', '609-555-2301'),
    ('Tom', '609-555-2301'),
    ('Tom', '609-555-2301'),
    ('Ryan', '609-555-4030'),
    ('Ryan', '609-555-4030'),
    ('Ryan', '609-555-4030'),
    ('Matt', '732-555-4109'),
    ('Matt', '732-555-4109'),
    ('Jennifer', '732-555-0124'),
    ('Durga', '609-555-1102'),
    ('Rajkumar', '418-555-0123'),
    ('Thanmayi', '732-555-2181'),
    ('Mohit', '732-555-0021'),
    ('Nirmal', '732-555-2222'),
    ('Sri', '609-555-6090'),
    ('Bhargavi', '609-555-0326'),
    ('Karthik', '609-555-2000'),
    ('Devarsh', '732-555-8123'),
    ('Dhanush', '418-555-4321'),
    ('Pranit', '732-555-1112'),
    ('Sarathi', '609-555-9189'),
    ('Mohammad', '609-555-7522'),
    ('Shivrishvith', '732-555-9001'),
    ('Dhruvik', '732-555-1813'),
    ('Parth', '732-555-1812'),
    ('Pranav', '732-555-4198'),
    ('Saurabh', '609-555-1290'),
    ('Bhaskara', '609-555-9181'),
    ('Kunal', '609-555-5508'),
    ('Nimay', '609-555-5509'),
    ('Swetha', '732-555-5508'),
    ('Damodhar', '732-555-5509'),
    ('Shanmukhi', '732-555-1919'),
    ('Matt', '732-555-4109'),
    ('Venkat', '609-555-4031'),
    ('Keith', '609-555-3289'),
]

NOTES = ['extra spicy', 'extra sauce', 'burnt', '', '', '', '', '', '', '']

def random_timestamp(start_date, end_date):
    """Creates a random timestamp between two dates"""

    return random.randint(int(start_date.timestamp()), int(end_date.timestamp()))

def random_items(min_items, max_items):
    """Picks between min_items and max_items of random items from the menu"""

    items = []
    number_of_items = random.randint(min_items, max_items)
    while len(items) < number_of_items:
        item, price = random.choice(MENU)
        items.append({'name': item, 'price': price})

    return items

def random_order():
    """Generates a completely random order"""

    ts = random_timestamp(START_DATE, END_DATE)
    items = random_items(MIN_ITEMS, MAX_ITEMS)
    name, phone = random.choice(PEOPLE)
    notes = random.choice(NOTES)

    order = {
        'timestamp': ts,
        'name': name,
        'phone': phone,
        'items': items,
        'notes': notes,
    }

    return order

def random_order_list(num_orders):
    """Generates random orders in a list"""

    orders = []
    while len(orders) < num_orders:
        orders.append(random_order())
    return orders

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument("orders", type=int, help="how many orders to generate")
    parser.add_argument("outfile", help="JSON file to write to")
    args = parser.parse_args()

    orders = random_order_list(args.orders)

    with open(args.outfile, "w") as outfile:
        json.dump(orders, outfile, indent=4)

import json
import argparse

parser = argparse.ArgumentParser()
parser.add_argument('filename')
args = parser.parse_args()

with open(args.filename, 'r') as infile:
    order_list = json.load(infile)

customers = {}
items = {}
for order in order_list:
    customers[order['phone']] = order['name']
    for item in order['items']:
        name = item['name']
        price = item['price']
        if name in items:
            items[name]['orders'] += 1
        else:
            items[name] = {
              'price': price,
              'orders': 1
            }
with open("customers.json", 'w+') as outfile:
    json.dump(customers, outfile)
with open("items.json", 'w+') as outfile:
    json.dump(items, outfile)
print(customers)
print(items)

from datetime import datetime, timedelta, date

def my_datetime(dt):
    return dt.strftime('%Y %m %d %H %M %S')

def saturdays():
    saturday_list = []
    week = timedelta(days=7)
    current_date = date.today()
    days_to_next_saturday = timedelta(days=((5 - current_date.weekday()) % 7))
    next_saturday = current_date + days_to_next_saturday
    while next_saturday.year < current_date.year + 1:
        saturday_list.append(next_saturday)
        next_saturday += week
    return saturday_list

def first_or_fifteenth(our_date):
    if our_date.day in [1, 15] and our_date.weekday() not in [5, 6]:
        return True
    return False


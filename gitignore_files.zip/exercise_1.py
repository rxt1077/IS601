# Write a Python script gives a user up to three attempts to input the phrase "Hello World!"
# If the phrase is input correctly, print "Good job." and end the program.
# Each time the phrase is input incorrectly, print "Please try again."
# After three incorrect attempts print "Sorry, retries exceeded." and end the program.

attempts = 0
while attempts < 3:
    user_input = input()
    if user_input == "Hello world":
        print("Good job")
        break
    else:
        print("Please try again")
    attempts += 1
if attempts >= 3:
    print("Attempts exceeded")

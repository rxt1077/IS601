def count_caps(sentence):
    if type(sentence) is not str:
        return 0

    count = 0
    for word in sentence.split():
        if word[0].isupper():
            count += 1
    return count

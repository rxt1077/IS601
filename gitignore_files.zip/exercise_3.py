import json

class Exercise3():
    def __init__(self, filename):
        with open(filename) as f:
            json_data = json.load(f)
            self.username = json_data["username"]
            self.time_remaining = json_data["time_remaining"]
            self.cart = json_data["shopping_cart"]

    def get_total(self):
        total = 0
        for key, value in self.cart.items():
            total += value
        return total

    def get_username(self):
        return self.username

    def get_time_remaining(self):
        return self.time_remaining

    def get_items(self):
        return list(self.cart.keys())

    def add_hour(self):
        self.time_remaining += 60